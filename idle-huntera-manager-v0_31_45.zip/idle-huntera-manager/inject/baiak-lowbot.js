// ==UserScript==
// @name         @WoLBots - Baiak Idle
// @namespace    wolbots
// @version      12.9.3
// @description  @WoLBots - interface personalizada + opções Idle Helper
// @match        https://baiakidle.com/jogar/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    console.log('[@WoLBots] Iniciando v12.9.3...');

    // =========================================================
    // HUNTS (seu mapa completo)
    // =========================================================
    const HUNT_MAP = {
        loot: {
            "Troll (lvl 1)": "troll-cave",
            "Elf (lvl 8)": "elf-lair",
            "Amazon (lvl 9)": "amazon-camp",
            "Minotaur (lvl 10)": "minotaur",
            "Stone Refiner (lvl 30)": "refiner-cave",
            "Glooth Bandit (lvl 60)": "glooth-cave",
            "Orclops (lvl 100)": "orclops-cave",
            "Wyrm (lvl 130)": "wyrm-cave",
            "Werehyaena (lvl 140)": "werehyaena-cave",
            "Dark Torturer (lvl 150)": "darktorturer-cave",
            "Wereliones (lvl 170)": "wereliones-cave",
            "Draken (lvl 180)": "draken-lair",
            "Undead Dragon (lvl 200)": "undeadragon-lair",
            "Cliff Strider (lvl 200)": "cliffstrider-cave",
            "Hideous Fungus (lvl 200)": "hideous-fungus",
            "Dread Intruder (lvl 200)": "dreadintruder-cave"
        },
        exp: {
            "Kongra (lvl 10)": "kongra",
            "Cyclopolis (lvl 15)": "cyclopolis",
            "Corym Skirmisher (lvl 30)": "corym-cave",
            "Giant Spider (lvl 50)": "giant-spider",
            "Craler (lvl 50)": "crawler-cave",
            "Hero (lvl 60)": "hero-cave",
            "Cult (lvl 80)": "cult-cave",
            "Dragon Lair (lvl 80)": "dragon-lair",
            "Werebagde (lvl 90)": "werebadge-cave",
            "Hydra (lvl 100)": "hydra-cave",
            "Behemoth (lvl 100)": "behemoth-cave",
            "Grim Reaper (lvl 130)": "grimreaper-cave",
            "Asuras (lvl 150)": "asura-lair",
            "Mitmah Seer (lvl 180)": "mitmah-cave",
            "Cobras (lvl 190)": "cobra-cave",
            "Magma Crawler (lvl 200)": "magmacrawler-cave",
            "Falcon (lvl 210)": "falcon"
        }
    };

    // =========================================================
    // 1. PACOTES
    // =========================================================
    function packStr(value) {
        const bytes = new TextEncoder().encode(value);
        if (bytes.length < 32) {
            const out = new Uint8Array(1 + bytes.length);
            out[0] = 0xa0 | bytes.length;
            out.set(bytes, 1);
            return out;
        }
        if (bytes.length < 256) {
            const out = new Uint8Array(2 + bytes.length);
            out[0] = 0xd9; out[1] = bytes.length;
            out.set(bytes, 2);
            return out;
        }
        const out = new Uint8Array(3 + bytes.length);
        out[0] = 0xda;
        out[1] = (bytes.length >> 8) & 0xff;
        out[2] = bytes.length & 0xff;
        out.set(bytes, 3);
        return out;
    }

    function packBool(value) {
        return new Uint8Array([value ? 0xc3 : 0xc2]);
    }

    function packRoomRecord(type, keys, values) {
        const parts = [
            new Uint8Array([0x0d]),
            packStr(type),
            new Uint8Array([0xd4, 0x72, 0x40, 0x90 | keys.length])
        ];
        for (const key of keys) parts.push(packStr(key));
        parts.push(...values);

        let size = 0;
        for (const p of parts) size += p.length;
        const raw = new Uint8Array(size);
        let offset = 0;
        for (const p of parts) {
            raw.set(p, offset);
            offset += p.length;
        }
        let binary = '';
        for (const b of raw) binary += String.fromCharCode(b);
        return btoa(binary);
    }

    const SELL_ALL_BASE64 = packRoomRecord("sellall", ["protected"], [packBool(false)]);
    const OPEN_ALL_GLOOTH_BASE64 = packRoomRecord("useitem", ["name", "from", "all"], [
        packStr("glooth bag"), packStr("backpack"), packBool(true)
    ]);

    function bagMovePacket(hash, to) {
        return packRoomRecord("bagmove", ["hash", "to"], [packStr(hash), packStr(to)]);
    }

    function modePacket(mode) {
        return packRoomRecord("mode", ["mode"], [packStr(mode)]);
    }

    function stagePacket(huntId) {
        return packRoomRecord("stage", ["huntId"], [packStr(huntId)]);
    }

    // =========================================================
    // 2. WEBSOCKET + MODO LEVE
    // =========================================================
    const sockets = new Map();
    const OriginalWebSocket = window.WebSocket;
    let gameplaySocket = null;
    let modoLeveEnabled = localStorage.getItem('wolbots-modo-leve') === '1';
    let botMasterEnabled = localStorage.getItem('wolbots-master') !== '0';

    function roomMessageType(bytes) {
        if (!bytes || bytes[0] !== 0x0d || bytes.length < 2) return '';
        const prefix = bytes[1];
        let offset = 2;
        let length = 0;
        if ((prefix & 0xe0) === 0xa0) {
            length = prefix & 0x1f;
        } else if (prefix === 0xd9) {
            length = bytes[2] ?? 0;
            offset = 3;
        } else if (prefix === 0xda) {
            length = ((bytes[2] ?? 0) << 8) | (bytes[3] ?? 0);
            offset = 4;
        } else return '';
        if (length <= 0 || offset + length > bytes.length) return '';
        try {
            return new TextDecoder().decode(bytes.subarray(offset, offset + length)).toLowerCase();
        } catch {
            return '';
        }
    }

    function shouldDropFx(bytes) {
        return modoLeveEnabled && roomMessageType(bytes) === 'fx';
    }

    window.WebSocket = function (url, protocols) {
        const ws = protocols !== undefined ? new OriginalWebSocket(url, protocols) : new OriginalWebSocket(url);
        if (/baiakidle\.com/i.test(String(url))) {
            sockets.set(String(url), ws);

            const originalAdd = ws.addEventListener.bind(ws);
            const wrapMap = new WeakMap();

            ws.addEventListener = function (type, listener, options) {
                if (type === 'message' && typeof listener === 'function') {
                    const wrapped = function (event) {
                        if (event.data instanceof ArrayBuffer) {
                            const bytes = new Uint8Array(event.data);
                            const type = roomMessageType(bytes);

                            // Identifica o socket real de gameplay pelos pacotes
                            // que sabemos que pertencem ao estado da sala/hunt.
                            if (
                                type.includes('.stage.') ||
                                type.includes('.citypos.') ||
                                type.includes('.visibility.') ||
                                type.includes('.mode.') ||
                                type.includes('.cpong.')
                            ) {
                                gameplaySocket = ws;
                            }

                            if (modoLeveEnabled && shouldDropFx(bytes)) return;
                        }
                        return listener.call(this, event);
                    };
                    wrapMap.set(listener, wrapped);
                    return originalAdd(type, wrapped, options);
                }
                return originalAdd(type, listener, options);
            };

            let userOnMessage = null;
            Object.defineProperty(ws, 'onmessage', {
                configurable: true,
                enumerable: true,
                get() { return userOnMessage; },
                set(fn) {
                    userOnMessage = fn;
                    if (!fn) return;
                    originalAdd('message', function (event) {
                        if (event.data instanceof ArrayBuffer) {
                            const bytes = new Uint8Array(event.data);
                            const type = roomMessageType(bytes);

                            if (
                                type.includes('.stage.') ||
                                type.includes('.citypos.') ||
                                type.includes('.visibility.') ||
                                type.includes('.mode.') ||
                                type.includes('.cpong.')
                            ) {
                                gameplaySocket = ws;
                            }

                            if (modoLeveEnabled && shouldDropFx(bytes)) return;
                        }
                        fn.call(ws, event);
                    });
                }
            });
        }
        return ws;
    };
    window.WebSocket.prototype = OriginalWebSocket.prototype;
    Object.setPrototypeOf(window.WebSocket, OriginalWebSocket);

    const nativeSend = OriginalWebSocket.prototype.send;
    OriginalWebSocket.prototype.send = function (data) {
        if (/baiakidle\.com/i.test(this.url)) {
            if (!sockets.has(this.url)) sockets.set(this.url, this);

            // O próprio jogo revela qual socket é o de gameplay quando
            // o usuário troca manualmente de cidade/hunt. Fixamos esse socket
            // para que mode.hunt e stage.huntId nunca sejam enviados para outro.
            try {
                let bytes = null;
                if (data instanceof ArrayBuffer) bytes = new Uint8Array(data);
                else if (ArrayBuffer.isView(data)) {
                    bytes = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
                }
                if (bytes) {
                    const text = new TextDecoder().decode(bytes).toLowerCase();
                    if (text.includes('stage') && text.includes('huntid')) {
                        gameplaySocket = this;
                        console.log('[@WoLBots] Gameplay socket confirmado pelo pacote stage/huntId');
                    }
                }
            } catch (e) {}
        }
        return nativeSend.call(this, data);
    };

    function getGameplaySocket() {
        // Prioriza o socket identificado pelos pacotes reais de gameplay.
        if (gameplaySocket && gameplaySocket.readyState === 1) {
            return gameplaySocket;
        }

        // Fallback para o comportamento antigo caso o socket ainda não tenha
        // recebido nenhum pacote de identificação.
        for (const [url, ws] of sockets) {
            if (ws.readyState === 1 && !/chat|rt3/i.test(url)) return ws;
        }
        for (const [url, ws] of sockets) {
            if (ws.readyState === 1) return ws;
        }
        return null;
    }

    function sendRawPacketOnSocket(ws, base64) {
        if (!ws || ws.readyState !== 1) return false;
        try {
            const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
            ws.send(bytes);
            return true;
        } catch (e) {
            return false;
        }
    }

    function sendRawPacket(base64) {
        return sendRawPacketOnSocket(getGameplaySocket(), base64);
    }

    // =========================================================
    // 3. VARIÁVEIS
    // =========================================================
    const PANEL_ID = 'panel-wolbots';
    const OVERLAY_ID = 'wolbots-overlay';

    let autoSellEnabled = localStorage.getItem('wolbots-auto-sell') === '1';
    let autoOpenGloothEnabled = localStorage.getItem('wolbots-auto-glooth') === '1';
    let autoTransferEnabled = localStorage.getItem('wolbots-auto-transfer') === '1';
    let autoReconnectEnabled = localStorage.getItem('wolbots-auto-reconnect') === '1';
    let autoHuntEnabled = localStorage.getItem('wolbots-auto-hunt') === '1';

    let reconInterval = parseInt(localStorage.getItem('wolbots-recon-interval') || '15');

    let sellingInProgress = false;
    let lastSellTime = 0;
    let lastReconnectAttempt = 0;
    let lastGloothTime = 0;
    let lastTransferTime = 0;
    let lastHuntAttempt = 0;
    let statusLockUntil = 0;
    let sellPhase = 'aguardando';

    let salesCount = parseInt(localStorage.getItem('wolbots-sales') || '0');
    let reconnectCount = parseInt(localStorage.getItem('wolbots-reconnects') || '0');
    let deathCount = parseInt(localStorage.getItem('wolbots-deaths') || '0');

    let selectedHuntId = localStorage.getItem('wolbots-selected-hunt-id') || '';
    let selectedHuntName = localStorage.getItem('wolbots-selected-hunt') || '';

    const TRANSFER_INTERVAL = 4000;
    const GLOOTH_COOLDOWN = 11000;

    let transferTiers = {
        rare: localStorage.getItem('wolbots-tier-rare') === '1',
        epic: localStorage.getItem('wolbots-tier-epic') !== '0',
        legendary: localStorage.getItem('wolbots-tier-legendary') !== '0',
        mythical: localStorage.getItem('wolbots-tier-mythical') !== '0'
    };

    let wasDisconnected = false;

    if (document.getElementById(PANEL_ID)) return;

    // =========================================================
    // 4. CSS (botão com neon forte + sem borda)
    // =========================================================
    const style = document.createElement('style');
    style.id = 'wolbots-style';
    style.textContent = `
        /* =====================================================
           PAINEL LATERAL
           Usa a MESMA estrutura visual do card TibiaBot.Online.
           Não sobrescrevemos .panel/.body/.tb-brand-title/.tb-open-btn:
           o próprio Baiak fornece esses estilos.
        ===================================================== */
        #panel-wolbots {
            position: relative;
        }

        /* =====================================================
           BOTÃO: MESMO VISUAL DO TIBIABOT + BORDA ANIMADA
           A animação fica somente na borda; o botão continua
           dourado e ocupa toda a largura do card.
        ===================================================== */
        #panel-wolbots .tb-open-wrap {
            position: relative;
            width: 100%;
            height: 34px;
            min-height: 34px;
            box-sizing: border-box;
            border-radius: 8px;
            overflow: hidden;
            isolation: isolate;
        }

        /* A animação ocupa EXATAMENTE a mesma caixa externa do botão. */
        #panel-wolbots .tb-open-wrap::before {
            content: "";
            position: absolute;
            inset: -60%;
            z-index: 0;
            background: conic-gradient(
                from var(--wolbots-angle, 0deg),
                transparent 0%,
                transparent 35%,
                #f5e6b8 48%,
                #d4a24c 52%,
                #f5e6b8 56%,
                transparent 65%,
                transparent 100%
            );
            animation: wolbots-open-orbit 2.4s linear infinite;
        }

        /* Máscara interna: mantém somente uma borda fina de luz. */
        #panel-wolbots .tb-open-wrap::after {
            content: "";
            position: absolute;
            inset: 2px;
            z-index: 0;
            border-radius: 6px;
            background: rgba(12, 14, 18, 0.55);
            pointer-events: none;
        }

        #panel-wolbots .tb-open-btn {
            position: absolute;
            inset: 2px;
            z-index: 1;
            width: calc(100% - 4px);
            height: 30px;
            min-height: 30px;
            margin: 0;
            border: 0;
            border-radius: 6px;
            cursor: pointer;
            font: inherit;
            font-size: 12px;
            font-weight: 700;
            color: #e8c34e;
            background: linear-gradient(180deg, #3a3a37, #24242c);
            box-shadow:
                inset 0 1px 0 rgba(255,255,255,.10),
                0 0 5px rgba(232,195,78,.32),
                0 0 12px rgba(232,195,78,.14);
            transition: filter .2s ease, box-shadow .25s ease;
        }

        #panel-wolbots .tb-open-btn:hover {
            filter: brightness(1.05);
            box-shadow:
                inset 0 1px 0 rgba(255,255,255,.12),
                0 0 7px rgba(232,195,78,.82),
                0 0 15px rgba(232,195,78,.48);
        }

        #panel-wolbots .tb-open-btn:active {
            filter: brightness(.98);
        }

        @property --wolbots-angle {
            syntax: "<angle>";
            inherits: false;
            initial-value: 0deg;
        }

        @keyframes wolbots-open-orbit {
            0% { --wolbots-angle: 0deg; }
            100% { --wolbots-angle: 360deg; }
        }


        /* =====================================================
           CORES DAS RARIDADES
           Somente visual; não altera checkboxes, filtros ou lógica.
        ===================================================== */
        #wolbots-window label:has(#tier-rare) {
            color: #4a90e8 !important;
            text-shadow: 0 0 5px rgba(74,144,232,.35);
        }

        #wolbots-window label:has(#tier-epic) {
            color: #a05be0 !important;
            text-shadow: 0 0 5px rgba(160,91,224,.35);
        }

        #wolbots-window label:has(#tier-legendary) {
            color: #e8c34e !important;
            text-shadow: 0 0 5px rgba(232,195,78,.35);
        }

        #wolbots-window label:has(#tier-mythical) {
            color: #e0555a !important;
            text-shadow: 0 0 5px rgba(224,85,90,.35);
        }

        /* =====================================================
           NEON SUAVE NAS FONTES DO PAINEL
           Apenas aparência: nenhuma lógica, macro ou controle é alterado.
        ===================================================== */
        #wolbots-window,
        #wolbots-window label,
        #wolbots-window p,
        #wolbots-window span,
        #wolbots-window strong {
            text-shadow:
                0 0 4px rgba(255, 215, 100, .10),
                0 0 9px rgba(255, 195, 45, .06);
        }

        #wolbots-title,
        #wolbots-window .low-module-title {
            text-shadow:
                0 0 5px rgba(255, 220, 100, .42),
                0 0 12px rgba(255, 195, 45, .18);
        }

        #wolbots-window .low-module-description {
            text-shadow:
                0 0 4px rgba(255, 215, 100, .13);
        }

        #wolbots-window .low-status strong {
            text-shadow:
                0 0 5px currentColor,
                0 0 10px rgba(255, 215, 100, .12);
        }

        /* Títulos/labels dourados usados dentro do painel */
        #wolbots-window h3,
        #wolbots-window h4,
        #wolbots-window .section-title,
        #wolbots-window .low-section-title {
            text-shadow:
                0 0 5px rgba(255, 220, 100, .35),
                0 0 11px rgba(255, 195, 45, .16);
        }

        /* =====================================================
           NEON DOS INTERRUPTORES
           O formato dos switches permanece exatamente o mesmo.
        ===================================================== */
        .low-switch input:checked + .low-slider {
            box-shadow:
                0 0 5px rgba(255, 215, 80, .45),
                0 0 11px rgba(255, 195, 45, .28);
        }

        .low-switch input:checked + .low-slider::before {
            box-shadow:
                0 0 5px rgba(255, 225, 120, .65);
        }

        #wolbots-overlay {
            position: fixed; inset: 0; display: none; align-items: center; justify-content: center;
            background: rgba(0,0,0,.72); z-index: 999999;
        }
        #wolbots-overlay.open { display: flex; }

        #wolbots-window {
            width: min(720px, calc(100vw - 36px));
            max-height: min(880px, calc(100vh - 36px));
            overflow: hidden; display: flex; flex-direction: column; color: #d4d9e2;
            border: 1px solid #383b3b; border-radius: 13px;
            background: linear-gradient(145deg, #090a0a, #151512, #080909);
            box-shadow: 0 25px 80px rgba(0,0,0,.85);
        }
        #wolbots-header {
            height: 54px; padding: 0 15px; display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid rgba(210,170,70,.18); flex-shrink: 0;
        }
        #wolbots-title { font-family: Georgia, serif; font-size: 17px; font-weight: 700; color: #d9b04f; }
        #wolbots-subtitle { margin-top: 1px; font-size: 10px; color: #85847d; }
        #wolbots-close {
            width: 28px; height: 28px; border: 0; border-radius: 6px;
            background: rgba(255,255,255,.03); color: #999; font-size: 17px; cursor: pointer;
        }
        #wolbots-close:hover { background: rgba(255,255,255,.08); color: #fff; }

        #wolbots-content {
            flex: 1; overflow-y: auto; padding: 10px 12px;
            display: flex; flex-direction: column; gap: 7px;
        }

        .low-module {
            padding: 10px 11px; border: 1px solid #30322f; border-radius: 9px;
            background: linear-gradient(145deg, rgba(20,20,18,.98), rgba(10,10,9,.98));
        }
        .low-module-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
        .low-module-title { font-family: Georgia, serif; font-size: 13.5px; font-weight: 700; color: #d3aa48; }
        .low-module-description { margin-top: 2px; font-size: 10.5px; line-height: 1.35; color: #85827a; }

        .low-switch { position: relative; width: 36px; height: 20px; flex-shrink: 0; }
        .low-switch input { opacity: 0; width: 0; height: 0; }
        .low-slider {
            position: absolute; inset: 0; cursor: pointer; border-radius: 20px;
            background: #252b31; border: 1px solid #32383e;
        }
        .low-slider::before {
            content: ""; position: absolute; width: 14px; height: 14px; left: 2px; top: 2px;
            border-radius: 50%; background: #a5a8aa; transition: .2s;
        }
        .low-switch input:checked + .low-slider { background: #80621f; border-color: #aa862f; }
        .low-switch input:checked + .low-slider::before { transform: translateX(15px); background: #f0d77b; }
        .low-switch input:disabled + .low-slider { opacity: 0.4; cursor: not-allowed; }

        .low-status {
            margin-top: 6px; padding-top: 5px; border-top: 1px solid rgba(255,255,255,.05);
            display: flex; align-items: center; justify-content: space-between;
            font-size: 10.5px; color: #85857f;
        }
        .low-status strong {
            color: #63c27f;
            text-shadow:
                0 0 5px rgba(99, 194, 127, .52),
                0 0 10px rgba(99, 194, 127, .20);
        }

        .low-status.off strong {
            color: #a55d52;
            text-shadow:
                0 0 5px rgba(165, 93, 82, .38),
                0 0 10px rgba(165, 93, 82, .14);
        }

        .sell-live-status {
            margin-top: 6px; font-size: 12px; font-weight: 600; min-height: 20px;
            letter-spacing: 0.35px; display: flex; align-items: center;
        }
        .sell-live-status .letter {
            display: inline-block;
            animation: letterBounce 1.1s ease-in-out infinite;
        }
        .sell-live-status .letter:nth-child(1) { animation-delay: 0.00s; }
        .sell-live-status .letter:nth-child(2) { animation-delay: 0.07s; }
        .sell-live-status .letter:nth-child(3) { animation-delay: 0.14s; }
        .sell-live-status .letter:nth-child(4) { animation-delay: 0.21s; }
        .sell-live-status .letter:nth-child(5) { animation-delay: 0.28s; }
        .sell-live-status .letter:nth-child(6) { animation-delay: 0.35s; }
        .sell-live-status .letter:nth-child(7) { animation-delay: 0.42s; }
        .sell-live-status .letter:nth-child(8) { animation-delay: 0.49s; }
        .sell-live-status .letter:nth-child(9) { animation-delay: 0.56s; }
        .sell-live-status .letter:nth-child(10) { animation-delay: 0.63s; }
        .sell-live-status .letter:nth-child(11) { animation-delay: 0.70s; }
        .sell-live-status .letter:nth-child(12) { animation-delay: 0.77s; }
        .sell-live-status .letter:nth-child(13) { animation-delay: 0.84s; }
        .sell-live-status .letter:nth-child(14) { animation-delay: 0.91s; }
        .sell-live-status .letter:nth-child(15) { animation-delay: 0.98s; }
        .sell-live-status .letter:nth-child(16) { animation-delay: 1.05s; }
        .sell-live-status .letter:nth-child(17) { animation-delay: 1.12s; }
        .sell-live-status .letter:nth-child(18) { animation-delay: 1.19s; }
        .sell-live-status .letter:nth-child(19) { animation-delay: 1.26s; }
        .sell-live-status .letter:nth-child(20) { animation-delay: 1.33s; }

        @keyframes letterBounce {
            0%, 100% { transform: translateY(0); }
            40% { transform: translateY(-4px); }
        }
        .sell-live-status.word-jump {
            animation: wordJump 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        @keyframes wordJump {
            0% { transform: translateY(0) scale(1); }
            30% { transform: translateY(-8px) scale(1.08); }
            60% { transform: translateY(0) scale(1); }
            100% { transform: translateY(0) scale(1); }
        }
        .sell-color-gold { color: #d9b04f; }
        .sell-color-green { color: #4ade80; }
        .sell-color-red { color: #f87171; }
        .sell-color-blue { color: #60a5fa; }

        .low-tiers-box {
            margin-top: 8px; padding: 8px 10px;
            background: rgba(0,0,0,.25); border: 1px solid #3a3a35; border-radius: 7px;
        }
        .low-tiers-title { font-size: 10.5px; color: #a89b6a; margin-bottom: 6px; }
        .low-tiers { display: grid; grid-template-columns: 1fr 1fr; gap: 5px 10px; }
        .low-tiers label {
            display: flex; align-items: center; gap: 5px; cursor: pointer;
            color: #d0cec4; font-size: 11.5px; user-select: none;
        }
        .low-tiers input[type="checkbox"] {
            width: 13px; height: 13px; accent-color: #d4a24c; cursor: pointer;
        }

        .low-sub {
            margin-top: 8px; padding: 8px 10px;
            background: rgba(0,0,0,.22); border: 1px solid #333; border-radius: 7px;
        }
        .low-sub-row {
            display: flex; align-items: center; justify-content: space-between;
            padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,.04);
        }
        .low-sub-row:last-child { border-bottom: none; }
        .low-sub-label { font-size: 11.5px; color: #c8c4b8; }
        .low-sub-desc { font-size: 10px; color: #777; margin-top: 1px; }
        .low-sub input[type="number"], .low-sub select {
            width: 140px; padding: 4px 6px; border-radius: 5px;
            border: 1px solid #444; background: #1a1a18; color: #ddd; font-size: 12px;
        }

        .low-stats-box {
            padding: 9px 11px; border: 1px solid #30322f; border-radius: 9px;
            background: rgba(0,0,0,.22);
        }
        .low-stats-title {
            font-family: Georgia, serif; font-size: 13px; font-weight: 700;
            color: #d3aa48; margin-bottom: 7px;
            display: flex; align-items: center; justify-content: space-between;
        }
        .low-stats-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 4px 12px;
            font-size: 11px;
        }
        .low-stats-grid span {
            color: #aaa79e;
            text-shadow:
                0 0 4px rgba(255, 215, 100, .12);
        }

        .low-stats-grid strong {
            color: #d9b04f;
            float: right;
            text-shadow:
                0 0 5px rgba(255, 220, 100, .48),
                0 0 11px rgba(255, 195, 45, .22);
        }

        .low-stats-box {
            box-shadow:
                0 0 5px rgba(255, 205, 60, .08),
                inset 0 0 10px rgba(255, 205, 60, .025);
        }

        .low-stats-title {
            color: #e0b84f;
            text-shadow:
                0 0 5px rgba(255, 220, 100, .75),
                0 0 12px rgba(255, 195, 45, .36),
                0 0 20px rgba(255, 180, 30, .14);
        }

        .low-stats-grid span {
            text-shadow:
                0 0 4px rgba(255, 220, 100, .20);
        }

        .low-stats-grid strong {
            text-shadow:
                0 0 5px rgba(255, 220, 100, .65),
                0 0 12px rgba(255, 195, 45, .30);
        }

        #low-online {
            text-shadow:
                0 0 5px rgba(99, 194, 127, .70),
                0 0 11px rgba(99, 194, 127, .30) !important;
        }

        #low-sales,
        #low-reconnects,
        #low-deaths {
            text-shadow:
                0 0 5px rgba(255, 220, 100, .65),
                0 0 12px rgba(255, 195, 45, .28);
        }

        .low-reset-btn {
            padding: 3px 9px; border-radius: 5px; border: 1px solid #555;
            background: rgba(255,255,255,.04); color: #ccc; font-size: 11px; cursor: pointer;
        }
        .low-reset-btn:hover { background: rgba(255,255,255,.08); }

        /* AutoHunt dual select */
        .hunt-dual {
            display: flex;
            gap: 8px;
            margin-top: 8px;
        }
        .hunt-dual > div { flex: 1; }
        .hunt-dual label {
            display: block;
            font-size: 11px;
            color: #d3aa48;
            margin-bottom: 3px;
        }
        .hunt-dual select {
            width: 100%;
            padding: 5px 6px;
            border-radius: 5px;
            border: 1px solid #444;
            background: #1a1a18;
            color: #ddd;
            font-size: 12px;
        }
    `;
    document.head.appendChild(style);

    // =========================================================
    // 5. PAINEL LATERAL (botão Abrir)
    // =========================================================
    function criarPainelLateral() {
        const aside = document.querySelector('aside.col');
        if (!aside || document.getElementById(PANEL_ID)) return;

        const panel = document.createElement('section');
        panel.className = 'panel';
        panel.id = PANEL_ID;
        panel.dataset.wolbots = 'sidebar';

        /*
         * Estrutura copiada do card nativo do TibiaBot.Online:
         * <section class="panel">
         *   <h3 class="tb-brand-title">...</h3>
         *   <div class="body">
         *     <div class="tb-open-wrap"><button class="tb-open-btn">...</button></div>
         *     <p class="tb-open-hint">...</p>
         *   </div>
         * </section>
         */
        panel.innerHTML = `
            <h3 class="tb-brand-title">@WoLBots</h3>
            <div class="body">
                <div class="tb-open-wrap">
                    <button
                        type="button"
                        class="tb-open-btn"
                        id="wolbots-open-btn"
                    >Abrir WoLBot</button>
                </div>
            </div>
        `;
        aside.insertBefore(panel, aside.firstChild);

        document.getElementById('wolbots-open-btn').addEventListener('click', abrirBot);
    }

    // =========================================================
    // 6. JANELA PRINCIPAL (seu painel original)
    // =========================================================
    function criarJanela() {
        if (document.getElementById(OVERLAY_ID)) return;

        const overlay = document.createElement('div');
        overlay.id = OVERLAY_ID;
        overlay.innerHTML = `
            <div id="wolbots-window">
                <div id="wolbots-header">
                    <div>
                        <div id="wolbots-title">@WoLBots - Baiak Idle</div>
                        <div id="wolbots-subtitle">Automação personalizada • v12.7</div>
                    </div>
                    <button id="wolbots-close">×</button>
                </div>
                <div id="wolbots-content">

                    <!-- BOT ATIVO -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">Bot Ativo</div>
                                <div class="low-module-description">Desliga todas as automações de uma vez</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-master" type="checkbox" ${botMasterEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                    </div>

                    <!-- STATUS & ESTATÍSTICAS -->
                    <div class="low-stats-box">
                        <div class="low-stats-title">
                            Status & Estatísticas
                            <button class="low-reset-btn" id="low-reset-stats">Resetar</button>
                        </div>
                        <div class="low-stats-grid">
                            <div><span>Jogo</span> <strong id="low-online" style="color:#63c27f">● Online</strong></div>
                            <div><span>Vendas</span> <strong id="low-sales">${salesCount}</strong></div>
                            <div><span>Reconnects</span> <strong id="low-reconnects">${reconnectCount}</strong></div>
                            <div><span>Mortes</span> <strong id="low-deaths">${deathCount}</strong></div>
                        </div>
                    </div>

                    <!-- AUTO SELL -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">AutoSell</div>
                                <div class="low-module-description">Vende o loot automaticamente via WebSocket.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-auto-sell" type="checkbox" ${autoSellEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                        <div id="low-auto-status" class="low-status ${autoSellEnabled ? '' : 'off'}">
                            <span>Status</span>
                            <strong>${autoSellEnabled ? '● Ativado' : '● Desativado'}</strong>
                        </div>
                        <div id="sell-live" class="sell-live-status sell-color-gold">Aguardando</div>
                    </div>

                    <!-- OPEN GLOOTH -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">Open All Glooth Bag</div>
                                <div class="low-module-description">Abre as Glooth Bags quando a venda está disponível e tem espaço.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-auto-glooth" type="checkbox" ${autoOpenGloothEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                        <div id="low-glooth-status" class="low-status ${autoOpenGloothEnabled ? '' : 'off'}">
                            <span>Status</span>
                            <strong>${autoOpenGloothEnabled ? '● Ativado' : '● Desativado'}</strong>
                        </div>
                    </div>

                    <!-- AUTO TRANSFER -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">AutoTransfer</div>
                                <div class="low-module-description">Move itens do Loot Pouch para o Backpack pelas raridades marcadas.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-auto-transfer" type="checkbox" ${autoTransferEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                        <div id="low-transfer-status" class="low-status ${autoTransferEnabled ? '' : 'off'}">
                            <span>Status</span>
                            <strong>${autoTransferEnabled ? '● Ativado' : '● Desativado'}</strong>
                        </div>
                        <div class="low-tiers-box">
                            <div class="low-tiers-title">Raridades para transferir:</div>
                            <div class="low-tiers">
                                <label><input id="tier-rare" type="checkbox" ${transferTiers.rare ? 'checked' : ''}> Rare</label>
                                <label><input id="tier-epic" type="checkbox" ${transferTiers.epic ? 'checked' : ''}> Epic</label>
                                <label><input id="tier-legendary" type="checkbox" ${transferTiers.legendary ? 'checked' : ''}> Legendary</label>
                                <label><input id="tier-mythical" type="checkbox" ${transferTiers.mythical ? 'checked' : ''}> Mythical</label>
                            </div>
                        </div>
                    </div>

                    <!-- MODO LEVE -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">Modo leve (sem VFX)</div>
                                <div class="low-module-description">Bloqueia packets fx para reduzir freeze em combate.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-modo-leve" type="checkbox" ${modoLeveEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                    </div>

                    <!-- AUTO RECONNECT -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">Auto Reconnect</div>
                                <div class="low-module-description">Reconecta automaticamente quando o jogo cair.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-auto-reconnect" type="checkbox" ${autoReconnectEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                        <div id="low-reconnect-status" class="low-status ${autoReconnectEnabled ? '' : 'off'}">
                            <span>Status</span>
                            <strong>${autoReconnectEnabled ? '● Ativado' : '● Desativado'}</strong>
                        </div>
                        <div class="low-sub">
                            <div class="low-sub-row">
                                <div>
                                    <div class="low-sub-label">Intervalo (s)</div>
                                    <div class="low-sub-desc">Mínimo entre tentativas</div>
                                </div>
                                <input id="low-recon-interval" type="number" value="${reconInterval}" min="8" max="60">
                            </div>
                        </div>
                    </div>

                    <!-- AUTO HUNT -->
                    <div class="low-module">
                        <div class="low-module-row">
                            <div>
                                <div class="low-module-title">Auto Hunt</div>
                                <div class="low-module-description">Volta para a hunt selecionada quando estiver na cidade.</div>
                            </div>
                            <label class="low-switch">
                                <input id="low-auto-hunt" type="checkbox" ${autoHuntEnabled ? 'checked' : ''}>
                                <span class="low-slider"></span>
                            </label>
                        </div>
                        <div id="low-hunt-status" class="low-status ${autoHuntEnabled ? '' : 'off'}">
                            <span>Status</span>
                            <strong>${autoHuntEnabled ? '● Ativado' : '● Desativado'}</strong>
                        </div>

                        <div class="hunt-dual">
                            <div>
                                <label>Hunt EXP</label>
                                <select id="low-hunt-exp">
                                    <option value="">— Selecione —</option>
                                </select>
                            </div>
                            <div>
                                <label>Hunt Loot</label>
                                <select id="low-hunt-loot">
                                    <option value="">— Selecione —</option>
                                </select>
                            </div>
                        </div>
                        <div style="margin-top:6px; font-size:11px; color:#888;">
                            ID atual: <strong id="low-hunt-id-display" style="color:#d9b04f">${selectedHuntId || '—'}</strong>
                        </div>
                    </div>

                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        // Eventos
        overlay.querySelector('#wolbots-close').addEventListener('click', fecharBot);
        overlay.addEventListener('click', e => { if (e.target === overlay) fecharBot(); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharBot(); });

        document.getElementById('low-reset-stats').addEventListener('click', () => {
            salesCount = 0; reconnectCount = 0; deathCount = 0;
            localStorage.setItem('wolbots-sales', '0');
            localStorage.setItem('wolbots-reconnects', '0');
            localStorage.setItem('wolbots-deaths', '0');
            document.getElementById('low-sales').textContent = '0';
            document.getElementById('low-reconnects').textContent = '0';
            document.getElementById('low-deaths').textContent = '0';
        });

        // Master
        const masterEl = document.getElementById('low-master');
        masterEl.addEventListener('change', function () {
            botMasterEnabled = this.checked;
            localStorage.setItem('wolbots-master', botMasterEnabled ? '1' : '0');
            syncMasterState();
        });

        const bind = (id, key, setter) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.addEventListener('change', function () {
                setter(this.checked);
                localStorage.setItem(key, this.checked ? '1' : '0');
                atualizarStatus(id.replace('low-auto-', 'low-').replace('low-modo-leve', 'low-modo') + '-status', this.checked);
            });
        };

        bind('low-auto-sell', 'wolbots-auto-sell', v => { autoSellEnabled = v; atualizarStatus('low-auto-status', v); });
        bind('low-auto-glooth', 'wolbots-auto-glooth', v => { autoOpenGloothEnabled = v; atualizarStatus('low-glooth-status', v); });
        bind('low-auto-transfer', 'wolbots-auto-transfer', v => { autoTransferEnabled = v; atualizarStatus('low-transfer-status', v); });
        bind('low-auto-reconnect', 'wolbots-auto-reconnect', v => { autoReconnectEnabled = v; atualizarStatus('low-reconnect-status', v); });
        bind('low-auto-hunt', 'wolbots-auto-hunt', v => { autoHuntEnabled = v; atualizarStatus('low-hunt-status', v); });
        bind('low-modo-leve', 'wolbots-modo-leve', v => { modoLeveEnabled = v; });

        const intervalEl = document.getElementById('low-recon-interval');
        if (intervalEl) {
            intervalEl.addEventListener('change', function () {
                reconInterval = Math.max(8, parseInt(this.value) || 15);
                localStorage.setItem('wolbots-recon-interval', reconInterval);
            });
        }

        // Tiers
        const tierMap = { 'tier-rare': 'rare', 'tier-epic': 'epic', 'tier-legendary': 'legendary', 'tier-mythical': 'mythical' };
        Object.keys(tierMap).forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.addEventListener('change', function () {
                    const key = tierMap[id];
                    transferTiers[key] = this.checked;
                    localStorage.setItem('wolbots-tier-' + key, this.checked ? '1' : '0');
                });
            }
        });

        // Popula hunts
        populateHuntSelects();

        // Eventos dos selects
        document.getElementById('low-hunt-exp').addEventListener('change', function () {
            if (this.value) {
                document.getElementById('low-hunt-loot').value = '';
                selectedHuntId = this.value;
                selectedHuntName = this.selectedOptions[0].textContent;
                localStorage.setItem('wolbots-selected-hunt-id', selectedHuntId);
                localStorage.setItem('wolbots-selected-hunt', selectedHuntName);
                document.getElementById('low-hunt-id-display').textContent = selectedHuntId;
            }
        });
        document.getElementById('low-hunt-loot').addEventListener('change', function () {
            if (this.value) {
                document.getElementById('low-hunt-exp').value = '';
                selectedHuntId = this.value;
                selectedHuntName = this.selectedOptions[0].textContent;
                localStorage.setItem('wolbots-selected-hunt-id', selectedHuntId);
                localStorage.setItem('wolbots-selected-hunt', selectedHuntName);
                document.getElementById('low-hunt-id-display').textContent = selectedHuntId;
            }
        });

        syncMasterState();
    }

    function populateHuntSelects() {
        const selExp = document.getElementById('low-hunt-exp');
        const selLoot = document.getElementById('low-hunt-loot');
        if (!selExp || !selLoot) return;

        selExp.innerHTML = '<option value="">— Selecione —</option>';
        selLoot.innerHTML = '<option value="">— Selecione —</option>';

        for (const [name, id] of Object.entries(HUNT_MAP.exp)) {
            const opt = document.createElement('option');
            opt.value = id;
            opt.textContent = name;
            if (selectedHuntId === id) opt.selected = true;
            selExp.appendChild(opt);
        }
        for (const [name, id] of Object.entries(HUNT_MAP.loot)) {
            const opt = document.createElement('option');
            opt.value = id;
            opt.textContent = name;
            if (selectedHuntId === id) opt.selected = true;
            selLoot.appendChild(opt);
        }
    }

    function syncMasterState() {
        const disabled = !botMasterEnabled;
        const ids = ['low-auto-sell', 'low-auto-glooth', 'low-auto-transfer', 'low-auto-reconnect', 'low-auto-hunt', 'low-modo-leve'];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.disabled = disabled;
        });
    }

    function atualizarStatus(id, ativo) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.toggle('off', !ativo);
        el.innerHTML = `<span>Status</span><strong>${ativo ? '● Ativado' : '● Desativado'}</strong>`;
    }

    // =========================================================
    // 7. STATUS DE VENDA
    // =========================================================
    function setSellStatus(novo, force = false) {
        const now = Date.now();
        if (!force && now < statusLockUntil) return;
        if (sellPhase === novo && !force) return;

        sellPhase = novo;
        const el = document.getElementById('sell-live');
        if (!el) return;

        let texto = '';
        let cor = 'sell-color-gold';
        let usarLetras = false;
        let wordJump = false;

        if (novo === 'indisponivel') {
            texto = 'Venda Indisponível';
            cor = 'sell-color-red';
            statusLockUntil = now + 3000;
        } else if (novo === 'aguardando_cd') {
            texto = 'Aguardando Cooldown';
            cor = 'sell-color-blue';
            usarLetras = true;
        } else if (novo === 'disponivel') {
            texto = 'Venda Disponível';
            cor = 'sell-color-gold';
        } else if (novo === 'efetuada') {
            texto = 'Venda Efetuada';
            cor = 'sell-color-green';
            wordJump = true;
            statusLockUntil = now + 3000;
        } else {
            texto = 'Aguardando';
            cor = 'sell-color-gold';
        }

        el.className = 'sell-live-status ' + cor;

        if (wordJump) {
            el.classList.add('word-jump');
            el.textContent = texto;
            setTimeout(() => el.classList.remove('word-jump'), 650);
        } else if (usarLetras) {
            el.innerHTML = texto.split('').map((c) =>
                c === ' ' ? '&nbsp;' : `<span class="letter">${c}</span>`
            ).join('');
        } else {
            el.textContent = texto;
        }
    }

    // =========================================================
    // 8. HELPERS
    // =========================================================
    function getInventoryState() {
        const match = /^\s*(\d+)\s*\/\s*(\d+)/.exec(document.getElementById('inv-count')?.textContent ?? '');
        if (!match) return null;
        const current = Number(match[1]);
        const capacity = Number(match[2]);
        const btn = document.getElementById('sell-all') || document.getElementById('sell-all-mini-btn');
        const sellCooldown = Boolean(btn?.classList.contains('cd'));
        return {
            current, capacity,
            free: capacity - current,
            canSell: Boolean(btn && !btn.disabled && !sellCooldown),
            sellCooldown
        };
    }

    function hasGloothBag() {
        return Boolean(document.querySelector('#backpack-grid img[alt*="glooth" i], #backpack-grid img[src*="glooth" i]'));
    }

    function isInCity() {
        const titulo = document.getElementById('wave-title');
        const texto = (titulo?.textContent || '').toLowerCase();
        return /cidade|city|lugar seguro|safe place|nada de hunt/i.test(texto);
    }

    function cliqueHumano(el) {
        if (!el) return;
        const opts = { bubbles: true, cancelable: true, view: window };
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.dispatchEvent(new MouseEvent('click', opts));
    }

    // =========================================================
    // 9. AUTO TRANSFER
    // =========================================================
    function verificarTransfer() {
        if (!botMasterEnabled || !autoTransferEnabled) return;
        if (Date.now() - lastTransferTime < TRANSFER_INTERVAL) return;

        const allowRare = document.getElementById('tier-rare')?.checked === true;
        const allowEpic = document.getElementById('tier-epic')?.checked === true;
        const allowLegendary = document.getElementById('tier-legendary')?.checked === true;
        const allowMythical = document.getElementById('tier-mythical')?.checked === true;

        const allowed = new Set();
        if (allowRare) allowed.add(2);
        if (allowEpic) allowed.add(3);
        if (allowLegendary) allowed.add(4);
        if (allowMythical) allowed.add(5);
        if (allowed.size === 0) return;

        const cells = document.querySelectorAll('#inv-grid .cell[data-tier]');
        let moved = 0;

        for (const cell of cells) {
            const tier = Number(cell.dataset.tier);
            if (!allowed.has(tier)) continue;
            if (!cell.querySelector('img, .qty, b')) continue;

            const hash = (cell.dataset.hash || '').trim();
            let ok = false;

            if (hash) {
                ok = sendRawPacket(bagMovePacket(hash, 'backpack'));
            } else {
                const opts = { bubbles: true, cancelable: true, view: window, shiftKey: true, button: 0 };
                cell.dispatchEvent(new MouseEvent('mousedown', opts));
                cell.dispatchEvent(new MouseEvent('mouseup', opts));
                cell.dispatchEvent(new MouseEvent('click', opts));
                ok = true;
            }

            if (ok) moved++;
        }

        if (moved > 0) {
            lastTransferTime = Date.now();
            console.log(`[@WoLBots] Transfer: ${moved}`);
        }
    }

    // =========================================================
    // 10. GLOOTH + SELL
    // =========================================================
    function verificarGloothESell() {
        if (!botMasterEnabled) return;
        if (!autoSellEnabled && !autoOpenGloothEnabled) return;
        if (sellingInProgress) return;

        const state = getInventoryState();
        if (!state) {
            setSellStatus('aguardando');
            return;
        }

        if (state.sellCooldown) {
            setSellStatus('aguardando_cd');
        } else if (state.canSell) {
            setSellStatus('disponivel');
        } else {
            setSellStatus('aguardando');
        }

        if (autoOpenGloothEnabled && state.canSell && state.free >= 3 && hasGloothBag()) {
            if (Date.now() - lastGloothTime > GLOOTH_COOLDOWN) {
                if (sendRawPacket(OPEN_ALL_GLOOTH_BASE64)) {
                    lastGloothTime = Date.now();
                    console.log('[@WoLBots] Glooth aberto');
                    sellingInProgress = true;
                    setTimeout(() => {
                        sellingInProgress = false;
                        tentarVender(state);
                    }, 1600);
                    return;
                }
            }
        }

        if (autoSellEnabled) tentarVender(state);
    }

    function tentarVender(state) {
        if (!botMasterEnabled || !autoSellEnabled || sellingInProgress) return;
        if (!state || !state.canSell) return;
        if (Date.now() - lastSellTime < 7000) return;

        sellingInProgress = true;

        if (sendRawPacket(SELL_ALL_BASE64)) {
            lastSellTime = Date.now();
            salesCount++;
            localStorage.setItem('wolbots-sales', salesCount);
            const s = document.getElementById('low-sales');
            if (s) s.textContent = salesCount;

            setSellStatus('efetuada', true);
            setTimeout(() => {
                setSellStatus('indisponivel', true);
                setTimeout(() => {
                    sellingInProgress = false;
                }, 3000);
            }, 3000);
        } else {
            sellingInProgress = false;
            setSellStatus('indisponivel', true);
        }
    }

    // =========================================================
    // 11. RECONNECT (só conta efetuados)
    // =========================================================
    function verificarReconnect() {
        if (!botMasterEnabled || !autoReconnectEnabled) return;

        const overlay = document.getElementById('conn-overlay');
        const isOpen = overlay && !overlay.classList.contains('hidden');

        const bodyText = (document.body?.innerText || '').toLowerCase();
        const pareceDesconectado = isOpen ||
            /conexão perdida|conexao perdida|desconectado|reconectar|tentar de novo|connection lost/i.test(bodyText);

        if (wasDisconnected && !pareceDesconectado) {
            wasDisconnected = false;
            reconnectCount++;
            localStorage.setItem('wolbots-reconnects', reconnectCount);
            const el = document.getElementById('low-reconnects');
            if (el) el.textContent = reconnectCount;
            console.log('[@WoLBots] Reconnect efetuado com sucesso');
        }

        if (!pareceDesconectado) {
            wasDisconnected = false;
            return;
        }

        wasDisconnected = true;

        if (Date.now() - lastReconnectAttempt < (reconInterval * 1000)) return;

        let btn = document.getElementById('conn-retry');
        if (!btn) {
            for (const b of document.querySelectorAll('button, a')) {
                const t = (b.innerText || '').toLowerCase();
                if (/reconectar|tentar de novo|tentar novamente|reconnect/i.test(t)) {
                    btn = b;
                    break;
                }
            }
        }

        if (btn) {
            cliqueHumano(btn);
        } else {
            location.reload();
        }

        lastReconnectAttempt = Date.now();
        console.log('[@WoLBots] Tentativa de reconnect enviada');
    }

    // =========================================================
    // 12. MORTE + HUNT
    // =========================================================
    let lastDeathCheck = 0;
    function verificarMorte() {
        if (Date.now() - lastDeathCheck < 8000) return;
        lastDeathCheck = Date.now();

        const hasRespawn = [...document.querySelectorAll('button')].some(b =>
            /respawn|renascer|templo|return to temple/i.test((b.innerText || '').toLowerCase())
        );

        if (hasRespawn && !window.__low_player_death) {
            window.__low_player_death = true;
            deathCount++;
            localStorage.setItem('wolbots-deaths', deathCount);
            const el = document.getElementById('low-deaths');
            if (el) el.textContent = deathCount;
            setTimeout(() => { window.__low_player_death = false; }, 20000);
        }
    }

    let autoHuntInProgress = false;

    function verificarAutoHunt() {
        if (!botMasterEnabled || !autoHuntEnabled) return;
        if (!selectedHuntId) return;
        if (autoHuntInProgress) return;
        if (Date.now() - lastHuntAttempt < 12000) return;
        if (!isInCity()) return;

        const ws = getGameplaySocket();
        if (!ws || ws.readyState !== 1) return;
        console.log('[@WoLBots] Auto Hunt: usando gameplay socket', ws.url);

        lastHuntAttempt = Date.now();
        autoHuntInProgress = true;

        const huntIdAtStart = selectedHuntId;
        const huntNameAtStart = selectedHuntName;

        // IMPORTANTE: captura o mesmo WebSocket para os dois pacotes.
        // Antes, o segundo pacote fazia uma nova seleção de socket 50 ms depois,
        // o que podia mandar mode.hunt e stage.huntId por sockets diferentes.
        const enviarSequencia = (tentativa) => {
            if (!ws || ws.readyState !== 1) {
                autoHuntInProgress = false;
                return;
            }

            const modeSent = sendRawPacketOnSocket(ws, modePacket("hunt"));
            console.log('[@WoLBots] Auto Hunt: mode.hunt enviado =', modeSent, 'tentativa', tentativa);

            if (!modeSent) {
                autoHuntInProgress = false;
                return;
            }

            // O cliente nativo envia mode.hunt antes de stage.huntId.
            // Um intervalo um pouco maior evita corrida com a troca de estado da tela.
            setTimeout(() => {
                const stageSent = sendRawPacketOnSocket(ws, stagePacket(huntIdAtStart));
                console.log('[@WoLBots] Auto Hunt: stage enviado =', stageSent, huntIdAtStart, 'tentativa', tentativa);

                // Se ainda estivermos na Cidade, faz uma segunda tentativa usando
                // o MESMO socket, sem esperar os 12 s do loop principal.
                setTimeout(() => {
                    if (isInCity() && tentativa < 2) {
                        console.log('[@WoLBots] Auto Hunt: ainda na Cidade, repetindo sequência');
                        enviarSequencia(tentativa + 1);
                    } else {
                        autoHuntInProgress = false;
                        if (!isInCity()) {
                            console.log('[@WoLBots] Auto Hunt →', huntNameAtStart, huntIdAtStart);
                        }
                    }
                }, 900);
            }, 180);
        };

        enviarSequencia(1);
    }

    // =========================================================
    // 13. LOOP
    // =========================================================
    setInterval(() => {
        verificarTransfer();
        verificarGloothESell();
        verificarReconnect();
        verificarMorte();
        verificarAutoHunt();
    }, 1100);

    // =========================================================
    // 14. ABRIR / FECHAR
    // =========================================================
    function abrirBot() {
        criarJanela();
        document.getElementById(OVERLAY_ID)?.classList.add('open');
    }
    function fecharBot() {
        document.getElementById(OVERLAY_ID)?.classList.remove('open');
    }

    // =========================================================
    // 15. INIT
    // =========================================================
    const wait = setInterval(() => {
        if (document.querySelector('aside.col')) {
            criarPainelLateral();
            clearInterval(wait);
            console.log('[@WoLBots] Pronto v12.9.3');
        }
    }, 500);

})();